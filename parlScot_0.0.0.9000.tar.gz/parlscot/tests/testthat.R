library(testthat)
library(parlscot)

test_check("parlscot")
